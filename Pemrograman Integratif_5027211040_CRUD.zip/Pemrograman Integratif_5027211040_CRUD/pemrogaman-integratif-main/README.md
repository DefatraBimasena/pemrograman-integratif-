
# Tugas Pemrogaman-integratif B

Projek gRPC CRUD ini akan create, read, update, delete, dan list database mahasiswa
## Bahasa dan persyaratan
-Node JS

-Javasript

-MySQL

-Rest API

-Client to server communication

## Instalasi
-Node JS

-NPM

## Langkah pengerjaan

1. Clone project git clone https://github.com/ilyasash/pemrogaman-integratif
2. Init code enc npm i
3. membuat database di mysql lalu hubungkan nama database nya ke
const PROTO_PATH = './service_def.proto'; ganti service_def dengan nama database yang dibuat


## Screenshots

![App Screenshot](https://i.ibb.co/JqtWmFT/image.png)
![App Screenshot](https://i.ibb.co/f4tM3Wn/image.png)



## Authors

- Maulana Ilyasa shafrizaliansyah_5027211065
- [@ilyasash](https://github.com/ilyasash)

